import { useState } from "react";

import {
  ArrowLeft,
  Upload,
  Recycle,
  CheckCircle2,
} from "lucide-react";

import { useNavigate } from "react-router-dom";

import {
  Card,
  CardContent,
} from "../../components/ui/card.jsx";

import Button from "../../components/ui/button.jsx";

import ActionConfirmationCard
  from "../../components/action/ActionConfirmationCard.jsx";

import api from "../../lib/axios.js";

function ReusePage() {

  const navigate = useNavigate();

  const [proofImage, setProofImage] =
    useState(null);

  const [notes, setNotes] =
    useState("");

  const [loading, setLoading] =
    useState(false);

  const [success, setSuccess] =
    useState(false);

  // FILE
  const handleFileChange = (e) => {

    const file =
      e.target.files[0];

    if (file) {
      setProofImage(file);
    }

  };

  // SUBMIT
  const handleSubmit =
    async () => {

      if (!proofImage) {

        alert(
          "Upload bukti terlebih dahulu"
        );

        return;
      }

      try {

        setLoading(true);

        // 1. CREATE ACTION
        const {
          data: actionData,
        } = await api.post(
          "/actions/",
          {
            prediction_id: null,

            action_type:
              "reuse",

            route:
              "mandiri",

            partner_name:
              null,

            notes,
          }
        );

        const actionId =
          actionData.action_id;

        // 2. UPLOAD PROOF
        const formData =
          new FormData();

        formData.append(
          "file",
          proofImage
        );

        await api.post(
          `/actions/${actionId}/proof`,
          formData,
          {
            headers: {
              "Content-Type":
                "multipart/form-data",
            },
          }
        );

        setSuccess(true);

      } catch (err) {

        console.error(err);

        alert(
          "Gagal mengirim aksi"
        );

      } finally {

        setLoading(false);

      }

    };

  // SUCCESS
  if (success) {

    return (

      <div className="min-h-screen bg-gray-50 px-4 py-10">

        <div className="max-w-xl mx-auto">

          <ActionConfirmationCard
            title="Aksi Reuse Berhasil Dikirim"
            description="Aksi reuse kamu sedang menunggu verifikasi admin."
          />

        </div>

      </div>

    );

  }

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-6">

      <div className="max-w-3xl mx-auto space-y-6">

        {/* BACK */}
        <Button
          variant="ghost"
          className="gap-2"
          onClick={() =>
            navigate(-1)
          }
        >

          <ArrowLeft className="w-4 h-4" />

          Kembali

        </Button>

        {/* HEADER */}
        <Card className="border-0 shadow-sm overflow-hidden">

          <div className="bg-gradient-to-r from-emerald-600 to-green-500 p-6 text-white">

            <div className="flex items-center gap-4">

              <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center">

                <Recycle className="w-7 h-7" />

              </div>

              <div>

                <h1 className="text-2xl font-black">

                  Reuse Action

                </h1>

                <p className="text-emerald-50 mt-1">

                  Gunakan kembali barang agar
                  mengurangi limbah.

                </p>

              </div>

            </div>

          </div>

          <CardContent className="p-6 space-y-6">

            {/* INSTRUCTION */}
            <div className="space-y-3">

              <h2 className="text-lg font-bold text-gray-900">

                Langkah Reuse

              </h2>

              <div className="space-y-2 text-sm text-gray-600">

                <div className="flex gap-2">

                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5" />

                  <span>
                    Gunakan kembali barang yang
                    masih layak.
                  </span>

                </div>

                <div className="flex gap-2">

                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5" />

                  <span>
                    Dokumentasikan hasil reuse.
                  </span>

                </div>

                <div className="flex gap-2">

                  <CheckCircle2 className="w-4 h-4 text-emerald-600 mt-0.5" />

                  <span>
                    Upload bukti reuse untuk
                    diverifikasi admin.
                  </span>

                </div>

              </div>

            </div>

            {/* FILE */}
            <div className="space-y-3">

              <label className="text-sm font-semibold text-gray-700">

                Upload Bukti

              </label>

              <label className="border-2 border-dashed border-gray-300 rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer hover:border-emerald-500 transition">

                <Upload className="w-8 h-8 text-gray-400 mb-3" />

                <span className="text-sm text-gray-600">

                  Klik untuk upload foto reuse

                </span>

                {proofImage && (

                  <p className="mt-3 text-sm font-medium text-emerald-700">

                    {proofImage.name}

                  </p>

                )}

                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={
                    handleFileChange
                  }
                />

              </label>

            </div>

            {/* NOTES */}
            <div className="space-y-3">

              <label className="text-sm font-semibold text-gray-700">

                Cerita Singkat

              </label>

              <textarea
                rows={5}
                placeholder="Ceritakan bagaimana kamu melakukan reuse..."
                className="w-full rounded-2xl border border-gray-300 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-emerald-500"
                value={notes}
                onChange={(e) =>
                  setNotes(
                    e.target.value
                  )
                }
              />

            </div>

            {/* BUTTON */}
            <Button
              className="w-full rounded-2xl py-6 text-base"
              onClick={handleSubmit}
              disabled={loading}
            >

              {loading
                ? "Mengirim..."
                : "Kirim Aksi"}

            </Button>

          </CardContent>

        </Card>

      </div>

    </div>
  );
}

export default ReusePage;