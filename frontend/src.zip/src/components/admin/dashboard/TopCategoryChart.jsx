import {
  ResponsiveContainer,
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from "recharts";

const COLORS = ["#16a34a", "#2563eb", "#d97706", "#7c3aed", "#db2777", "#0891b2"];

const LABEL_MAP = {
  organik: "Organik",
  plastik_pet: "Plastik PET",
  plastik_hdpe: "Plastik HDPE",
  plastik_campuran: "Plastik Camp.",
  kertas_bersih: "Kertas Bersih",
  kertas_kotor: "Kertas Kotor",
  kaca_utuh: "Kaca Utuh",
  kaca_pecah: "Kaca Pecah",
};

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white border border-gray-100 rounded-xl shadow-md px-4 py-2 text-sm">
      <p className="text-gray-500 mb-1">{LABEL_MAP[payload[0].payload.category] ?? payload[0].payload.category}</p>
      <p className="font-semibold text-gray-800">{payload[0].value} scan</p>
    </div>
  );
};

const TopCategoryChart = ({ data }) => {
  const formatted = data.map((d) => ({
    ...d,
    label: LABEL_MAP[d.category] ?? d.category,
  }));

  return (
    <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
      <div className="mb-5">
        <h2 className="text-base font-semibold text-gray-800">Top Kategori Sampah</h2>
        <p className="text-xs text-gray-400 mt-0.5">Frekuensi kategori terdeteksi AI</p>
      </div>

      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={formatted} margin={{ top: 4, right: 4, bottom: 0, left: -16 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
          <XAxis
            dataKey="label"
            tick={{ fontSize: 11, fill: "#9ca3af" }}
            tickLine={false}
            axisLine={false}
          />
          <YAxis
            allowDecimals={false}
            tick={{ fontSize: 11, fill: "#9ca3af" }}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip content={<CustomTooltip />} />
          <Bar dataKey="count" radius={[6, 6, 0, 0]} maxBarSize={48}>
            {formatted.map((_, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default TopCategoryChart;